import subprocess
import tkinter


def encrypt():
    subprocess.Popen(["python", "encrypt.py"])  # Replace 'encrypt.py' with your actual encryption file
    window.destroy()  # Close the login window after redirection


def decrypt():
    subprocess.Popen(["python", "decrypt.py"])  # Replace 'decrypt.py' with your actual decryption file
    window.destroy()  # Close the login window after redirection


def short():
    subprocess.Popen(["python", "urlshort.py"])  # Replace 'decrypt.py' with your actual decryption file
    window.destroy()  # Close the login window after redirection


window = tkinter.Tk()
window.title("Selector")
window.geometry('340x440')
window.configure(bg='#333333')

frame = tkinter.Frame(bg='#333333')

# Creating buttons
encrypt_button = tkinter.Button(frame, text="Encrypt", bg='#FF3399', fg='#FFFFFF', font=("Arial", 16), command=encrypt)
decrypt_button = tkinter.Button(frame, text="Decrypt", bg='#FF3399', fg='#FFFFFF', font=("Arial", 16), command=decrypt)
urlshort_button = tkinter.Button(frame, text="Url Shortener", bg='#FF3399', fg='#FFFFFF', font=("Arial", 16), command=short)

# Placing buttons on the screen
encrypt_button.grid(row=0, column=0, padx=50, pady=30)
decrypt_button.grid(row=0, column=1, padx=50, pady=30)
urlshort_button.grid(row=1, column=0, pady=30, columnspan=2)

frame.pack()

window.mainloop()
