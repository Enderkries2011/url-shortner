import subprocess
import tkinter
from tkinter import messagebox
import base64

window = tkinter.Tk()
window.title("Decrypter")
window.geometry('340x440')
window.configure(bg='#333333')


def back():
    subprocess.Popen(["python", "selection.py"])  # Replace 'encrypt.py' with your actual encryption file
    window.destroy()  # Close the login window after redirection


def encrypt():
    input_string = username_entry.get().encode('utf-8')
    decrypted_message = base64.b64decode(input_string).decode('utf-8')
    output_box.delete('1.0', tkinter.END)  # Clear the previous output
    output_box.insert(tkinter.END, decrypted_message)  # Insert the new output text into the output box
    messagebox.showinfo(title="Decryption Success", message=f"See Output box for The decrypted message.\n")
    print("Successfully Decrypted!\nDecrypted Message:")
    print(decrypted_message)


frame = tkinter.Frame(bg='#333333')

# Adding the output box (Text widget)
output_box = tkinter.Text(frame, wrap=tkinter.WORD, font=("Arial", 16), height=6, width=30)

# Important
output_box.insert(tkinter.END, "Do not change\nOnly Copy Output")  # Insert the important text

# Creating widgets
login_label = tkinter.Label(
    frame, text="Decrypter", bg='#333333', fg='#FF3399', font=("Arial", 30))
username_label = tkinter.Label(
    frame, text="What do u want to Decrypt", bg='#333333', fg='#FFFFFF', font=("Arial", 16))
username_entry = tkinter.Entry(frame, font=("Arial", 16))
login_button = tkinter.Button(
    frame, text="Decrypt", bg='#FF3399', fg='#FFFFFF', font=("Arial", 16), command=encrypt)
back_button = tkinter.Button(
    frame, text="Go back", bg='#FF3399', fg='#FFFFFF', font=("Arial", 16), command=back)

# Placing widgets on the screen
login_label.grid(row=0, column=0, columnspan=2, sticky='news', pady=40)
username_label.grid(row=2, column=0)
username_entry.grid(row=2, column=1, pady=20)
login_button.grid(row=4, column=0, columnspan=2, pady=30)
output_box.grid(row=5, column=0, columnspan=2, pady=10)
back_button.grid(row=1, column=0, columnspan=2, padx=40, pady=20)

frame.pack()

window.mainloop()
